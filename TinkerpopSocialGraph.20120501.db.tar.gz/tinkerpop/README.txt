TinkerPop Social Graph
======================

As of May 1, 2012

Collected by Patrick Wagstrom <patrick@wagstrom.net>

Background
----------

This is the social graph extracted from the Tinkerpop stack on GitHub.
The data were collected using a spidering algorithm and the GitHub.com
public API. The program used is called [GitMiner][gitminer], and is from
a joint research project of IBM and the University of Nebraska, Lincoln.

Spidering Overview
------------------

The spidering began with the following projects in the Tinkerpop stack:

* tinkerpop/blueprints
* tinkerpop/gremlin
* tinkerpop/frames
* tinkerpop/furnace
* tinkerpop/pipes
* tinkerpop/rexster

For each project the following data were downloaded:

* All publicly available issues (including comments, events, etc)
* All publicly available pull requests
* Git repository from the main pull URL
* List of users who were explicitly marked as collaborators
* List of users that GitHub marked as contributors (someone who has
  committed code to a project)
* List of all users watching the project

This gave a set of a couple of thousand distinct users. For each
user the following things were downloaded:

* All information present in the general GitHub user profile
* List of all followers of the user
* List of all users that are being followed by the user
* List of all proejcts that are being watched by the user
* Information on all the gists created by the user
* Information on all the most recent events created by the user

Finally, we also parse the git repository information and link
up all of the users with the artifacts that they contributed to the
repository. This is generally done by matching on email addresses
and gravatar hashes.

Vertex/Edge/Property Information
--------------------------------

Unfortunately, these have not been explicitly documented yet. You can
find general information about the distribution of edges in `overview.txt`.
For the most part we have tried to be as explicit as possible.

Also, poke around the sourcecode for [GitMiner][gitminer]. In particular,
the following files may be interesting:

* [IndexNames.java][indexnames]: the names of every index in the database
* [IdCols.java][idcols]: the names of the id columns for the appropriate indices
* [VertexType.java][vertextype]: the names of all the vertex types
* [EdgeType.java][edgetype]: the names of all the edge labels
* [PropertyName.java][propertyname]: the names of all of the properties

Sample Fun Queries
------------------

Here are a couple of queries that should be fun enough to get you started.
They are presented on a single line so you can just paste them into your
gremlin console.

* Count the number of users who watch both gremlin and blueprints

    g.idx("repo-idx").get("reponame","tinkerpop/gremlin")._().in("REPO_WATCHED").as("user").out("REPO_WATCHED").has("reponame","tinkerpop/blueprints").back("user").dedup().count();
 
* Get the users the followers of Marko also follow most often

    m = [:]; g.idx("user-idx").get("login", "okram")._().out("FOLLOWER").out("FOLLOWING").login.groupCount(m).iterate(); m.sort{a,b -> a.value <=> b.value}

* Get all the gravatar hashes for people who have committed code to pipes

    g.idx("repo-idx").get("reponame","tinkerpop/pipes")._().in("REPOSITORY").out("AUTHOR").out("EMAIL").out("GRAVATAR_HASH").dedup().hash

Usage Rights
------------

This is the same data you could extract using our open source project,
[GitMiner][gitminer]. If you use this in some sort of research project
then a citation to GitMiner would be apprecaited.

If you want to do something really cool then email me and we can talk
about interesting questions.

Caveats
-------

This is scraped data. It is probably a little noisy. Some relationships
are not always symmetric. For example a user will likely have more
outgoing FOLLOWER links than incoming FOLLOWING links, even though they
are two sides of the same equation. This is because we have not scraped
everybody in GitHub, just those that were directly associated with the
tinkerpop stack.

[gitminer]: https://github.com/pridkett/gitminer
[indexnames]: https://github.com/pridkett/gitminer/blob/master/src/main/java/net/wagstrom/research/github/IndexNames.java
[idcols]: https://github.com/pridkett/gitminer/blob/master/src/main/java/net/wagstrom/research/github/IdCols.java
[vertextype]: https://github.com/pridkett/gitminer/blob/master/src/main/java/net/wagstrom/research/github/VertexType.java
[edgetype]: https://github.com/pridkett/gitminer/blob/master/src/main/java/net/wagstrom/research/github/EdgeType.java
[propertyname]: https://github.com/pridkett/gitminer/blob/master/src/main/java/net/wagstrom/research/github/PropertyName.java
